package it.openai.arezzobusmap

import android.Manifest
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
        setContent { MaterialTheme { ArezzoApp() } }
    }
}

@Composable
private fun ArezzoApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var line by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var time by remember { mutableStateOf(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))) }
    var status by remember { mutableStateOf("Inserisci una linea, una data e un orario.") }
    var results by remember { mutableStateOf<List<TripResult>>(emptyList()) }
    var selected by remember { mutableStateOf<TripResult?>(null) }
    var loading by remember { mutableStateOf(false) }
    var mapView by remember { mutableStateOf<MapView?>(null) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Arezzo Bus Map", style = MaterialTheme.typography.headlineSmall)
        Text("Linee urbane ed extraurbane · OpenStreetMap", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = line, onValueChange = { line = it }, label = { Text("Numero/nome linea") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Data (AAAA-MM-GG)") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Ora (HH:MM)") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        Button(
            enabled = !loading && line.isNotBlank(),
            onClick = {
                scope.launch {
                    loading = true
                    status = "Scaricamento e ricerca dei dati GTFS…"
                    try {
                        val found = withContext(Dispatchers.IO) { GtfsRepository.search(line.trim(), date.trim(), time.trim()) }
                        results = found
                        selected = found.firstOrNull()
                        status = if (found.isEmpty()) "Nessuna corsa trovata. Controlla linea, data e ora oppure verifica il feed aggiornato." else "Trovate ${found.size} corse compatibili. Seleziona una corsa per mostrarla."
                        selected?.let { drawTrip(mapView, it) }
                    } catch (e: Exception) {
                        status = "Errore nel caricamento GTFS: ${e.localizedMessage ?: "connessione o formato non valido"}"
                    } finally { loading = false }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (loading) "Ricerca in corso…" else "Cerca corse") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { centerOnUser(context, mapView) }, modifier = Modifier.weight(1f)) {
                Text("La mia posizione GPS")
            }
        }
        Text(status, style = MaterialTheme.typography.bodySmall)
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)
                    controller.setZoom(12.5)
                    controller.setCenter(GeoPoint(43.4631, 11.8796))
                    mapView = this
                }
            },
            update = { mapView = it }
        )
        if (results.isNotEmpty()) {
            Text("Corse disponibili", style = MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.heightIn(max = 150.dp)) {
                items(results.take(30), key = { it.tripId }) { item ->
                    TextButton(onClick = { selected = item; drawTrip(mapView, item) }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth()) {
                            Text("${item.routeShortName} · ${item.headsign.ifBlank { "Direzione non specificata" }}")
                            Text("${item.departure} · ${item.stopCount} fermate · ${item.tripId}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        Text("Dati programmati da Regione Toscana. La posizione GPS è quella del telefono, non del bus.", style = MaterialTheme.typography.labelSmall)
    }
}

private fun drawTrip(map: MapView?, trip: TripResult) {
    if (map == null) return
    map.overlays.clear()
    if (trip.shape.isNotEmpty()) {
        val line = Polyline(map).apply {
            setPoints(trip.shape.map { GeoPoint(it.first, it.second) })
            outlinePaint.strokeWidth = 8f
        }
        map.overlays.add(line)
    }
    trip.stops.forEachIndexed { index, stop ->
        val marker = Marker(map).apply {
            position = GeoPoint(stop.lat, stop.lon)
            title = stop.name
            snippet = "Fermata ${index + 1}"
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        }
        map.overlays.add(marker)
    }
    val pts = trip.shape.ifEmpty { trip.stops.map { it.lat to it.lon } }
    if (pts.isNotEmpty()) {
        map.controller.setCenter(GeoPoint(pts.first().first, pts.first().second))
        map.controller.setZoom(13.5)
    }
    map.invalidate()
}


private fun centerOnUser(context: android.content.Context, map: MapView?) {
    if (map == null) return
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!fine && !coarse) return
    try {
        val manager = context.getSystemService(android.content.Context.LOCATION_SERVICE) as LocationManager
        val location = (listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { manager.isProviderEnabled(it) }
            .mapNotNull { provider ->
                try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
            }).maxByOrNull { it.time } ?: return
        val point = GeoPoint(location.latitude, location.longitude)
        val marker = Marker(map).apply {
            position = point
            title = "La tua posizione"
            snippet = "Posizione stimata dal telefono"
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        }
        map.overlays.removeAll { it is Marker && it.title == "La tua posizione" }
        map.overlays.add(marker)
        map.controller.animateTo(point)
        map.controller.setZoom(16.0)
        map.invalidate()
    } catch (_: SecurityException) {
        // Il permesso può essere revocato in qualsiasi momento.
    }
}
