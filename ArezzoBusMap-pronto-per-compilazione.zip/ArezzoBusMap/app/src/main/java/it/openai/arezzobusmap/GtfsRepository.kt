package it.openai.arezzobusmap

import java.net.URL
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.zip.ZipInputStream

data class StopPoint(val id: String, val name: String, val lat: Double, val lon: Double)
data class TripResult(
    val tripId: String, val routeShortName: String, val headsign: String,
    val departure: String, val stopCount: Int,
    val shape: List<Pair<Double, Double>>, val stops: List<StopPoint>
)

internal object GtfsRepository {
    // Feed statico regionale indicizzato da Transitland; può cambiare URL/formato nel tempo.
    private const val FEED_URL = "https://regionetoscana.smartregion.toscana.it/mobility/artifacts/gtfs"

    fun search(query: String, dateText: String, timeText: String): List<TripResult> {
        val date = LocalDate.parse(dateText)
        val requestedTime = LocalTime.parse(timeText, DateTimeFormatter.ofPattern("H:mm"))
        val tables = downloadTables()
        val agencyNames = rows(tables["agency.txt"]).associate { it["agency_id"].orEmpty() to it["agency_name"].orEmpty() }
        val routes = rows(tables["routes.txt"])
            .filter { route ->
                val agencyId = route["agency_id"].orEmpty()
                val agencyName = agencyNames[agencyId].orEmpty()
                // Restringe il feed regionale agli ambiti urbani/extraurbani di Arezzo.
                agencyName.contains("arezzo", true) ||
                    agencyId.contains("arezzo", true) ||
                    route["route_long_name"].orEmpty().contains("arezzo", true)
            }
            .associateBy { it["route_id"].orEmpty() }
        val trips = rows(tables["trips.txt"])
        val stops = rows(tables["stops.txt"]).associateBy { it["stop_id"].orEmpty() }
        val stopTimes = rows(tables["stop_times.txt"]).groupBy { it["trip_id"].orEmpty() }
        val shapes = rows(tables["shapes.txt"]).groupBy { it["shape_id"].orEmpty() }
            .mapValues { (_, rows) -> rows.sortedBy { it["shape_pt_sequence"]?.toIntOrNull() ?: 0 }
                .mapNotNull { r -> pair(r["shape_pt_lat"], r["shape_pt_lon"]) } }
        val calendar = rows(tables["calendar.txt"]).associateBy { it["service_id"].orEmpty() }
        val exceptions = rows(tables["calendar_dates.txt"]).groupBy { it["service_id"].orEmpty() }
        val dayField = when (date.dayOfWeek) {
            DayOfWeek.MONDAY -> "monday"; DayOfWeek.TUESDAY -> "tuesday"; DayOfWeek.WEDNESDAY -> "wednesday"
            DayOfWeek.THURSDAY -> "thursday"; DayOfWeek.FRIDAY -> "friday"; DayOfWeek.SATURDAY -> "saturday"
            DayOfWeek.SUNDAY -> "sunday"
        }
        val ymd = date.format(DateTimeFormatter.BASIC_ISO_DATE)
        val output = mutableListOf<TripResult>()
        for (trip in trips) {
            val route = routes[trip["route_id"]] ?: continue
            val short = route["route_short_name"].orEmpty()
            val long = route["route_long_name"].orEmpty()
            if (!short.contains(query, true) && !long.contains(query, true)) continue
            val serviceId = trip["service_id"].orEmpty()
            val calendarRow = calendar[serviceId]
            var active = calendarRow != null &&
                ymd >= calendarRow["start_date"].orEmpty() && ymd <= calendarRow["end_date"].orEmpty() &&
                calendarRow[dayField] == "1"
            exceptions[serviceId].orEmpty().filter { it["date"] == ymd }.forEach {
                when (it["exception_type"]) { "1" -> active = true; "2" -> active = false }
            }
            if (!active) continue
            val tripTimes = stopTimes[trip["trip_id"]].orEmpty().sortedBy { it["stop_sequence"]?.toIntOrNull() ?: 0 }
            if (tripTimes.isEmpty()) continue
            val first = tripTimes.first()
            val departure = first["departure_time"].orEmpty().ifBlank { first["arrival_time"].orEmpty() }
            val depMinutes = parseGtfsTime(departure) ?: continue
            if (depMinutes < requestedTime.hour * 60 + requestedTime.minute) continue
            val stopPoints = tripTimes.mapNotNull { row ->
                stops[row["stop_id"]]?.let { s ->
                    val p = pair(s["stop_lat"], s["stop_lon"]) ?: return@let null
                    StopPoint(s["stop_id"].orEmpty(), s["stop_name"].orEmpty(), p.first, p.second)
                }
            }
            val shape = shapes[trip["shape_id"]].orEmpty()
            output += TripResult(
                tripId = trip["trip_id"].orEmpty(), routeShortName = short.ifBlank { long },
                headsign = trip["trip_headsign"].orEmpty(),
                departure = departure, stopCount = stopPoints.size, shape = shape, stops = stopPoints
            )
        }
        return output.sortedBy { parseGtfsTime(it.departure) ?: Int.MAX_VALUE }.take(100)
    }

    private fun downloadTables(): Map<String, String> {
        val connection = URL(FEED_URL).openConnection().apply {
            connectTimeout = 20000; readTimeout = 45000
            setRequestProperty("User-Agent", "ArezzoBusMap/0.1 (Android GTFS viewer)")
        }
        val result = mutableMapOf<String, String>()
        connection.getInputStream().use { input ->
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (!entry.isDirectory && entry.name.substringAfterLast('/') in setOf(
                        "routes.txt", "trips.txt", "stops.txt", "stop_times.txt", "calendar.txt",
                        "calendar_dates.txt", "shapes.txt", "agency.txt"
                    )) {
                        result[entry.name.substringAfterLast('/')] = zip.readBytes().toString(Charsets.UTF_8).removePrefix("\uFEFF")
                    }
                    zip.closeEntry()
                }
            }
        }
        if (!result.containsKey("routes.txt") || !result.containsKey("trips.txt") || !result.containsKey("stops.txt")) {
            throw IllegalStateException("Il feed scaricato non contiene le tabelle GTFS attese.")
        }
        return result
    }

    private fun rows(csv: String?): List<Map<String, String>> {
        if (csv.isNullOrBlank()) return emptyList()
        val lines = csv.lineSequence().filter { it.isNotBlank() }.iterator()
        if (!lines.hasNext()) return emptyList()
        val headers = parseCsvLine(lines.next()).map { it.trim() }
        return lines.asSequence().map { line ->
            val values = parseCsvLine(line)
            headers.mapIndexedNotNull { i, key -> if (key.isEmpty()) null else key to values.getOrElse(i) { "" } }.toMap()
        }.toList()
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = mutableListOf<String>(); val current = StringBuilder(); var quoted = false; var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> { current.append('"'); i++ }
                c == '"' -> quoted = !quoted
                c == ',' && !quoted -> { out += current.toString(); current.setLength(0) }
                else -> current.append(c)
            }
            i++
        }
        out += current.toString()
        return out
    }

    private fun pair(a: String?, b: String?): Pair<Double, Double>? {
        val lat = a?.toDoubleOrNull() ?: return null
        val lon = b?.toDoubleOrNull() ?: return null
        return lat to lon
    }
    private fun parseGtfsTime(value: String): Int? {
        val p = value.split(":")
        if (p.size != 3) return null
        return (p[0].toIntOrNull() ?: return null) * 60 + (p[1].toIntOrNull() ?: return null)
    }
}
