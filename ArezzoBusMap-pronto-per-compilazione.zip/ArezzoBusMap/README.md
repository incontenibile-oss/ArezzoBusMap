# Arezzo Bus Map — progetto Android (sorgenti)

Prototipo Kotlin/Jetpack Compose per cercare linee/corse GTFS e mostrare tracciato, fermate e posizione del telefono su OpenStreetMap.

## Stato
- Progetto sorgente preparato.
- Non è stato compilato né testato su un dispositivo in questa sessione: **non è un APK pronto**.
- Il feed GTFS regionale è scaricato dall'app all'avvio della ricerca. Formato e filtri vanno convalidati contro la versione corrente dei dati prima di una distribuzione.
- Il feed è quello regionale pubblicato da Regione Toscana: https://regionetoscana.smartregion.toscana.it/mobility/artifacts/gtfs
- Attribuzione dati richiesta dalla fonte: Regione Toscana, https://dati.toscana.it/
- Catalogo informativo: https://dati.toscana.it/dataset/rt-oraritb e https://dati.toscana.it/dataset/rt-datitp

## Aprire e compilare
1. Installa Android Studio recente con Android SDK (compile SDK 35) e JDK 17 o 21.
2. Apri questa cartella in Android Studio e attendi la sincronizzazione Gradle.
3. Seleziona un emulatore o un telefono Android con Internet e posizione attiva.
4. Esegui `app`.
5. Per creare un APK debug: Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s).

## Funzioni incluse nel prototipo
- Ricerca per numero/nome linea e selezione della data/ora.
- Caricamento del feed GTFS ZIP via HTTPS.
- Filtri per corse attive nel calendario e partenza compatibile con l'orario scelto.
- Disegno shape, fermate e posizione GPS su OpenStreetMap.
- Richiesta esplicita dei permessi di localizzazione.

## Limiti da verificare
- I feed regionali possono avere variazioni di schema, calendari eccezionali o dati incompleti. Il parser è volutamente minimale e va verificato sui dati correnti.
- La ricerca temporale usa la prima fermata/orario utile della corsa e non è un pianificatore multimodale.
- Non include GPS dell'autobus in tempo reale. Mostra soltanto la posizione del telefono.
- OpenStreetMap è la cartografia; per l'uso pubblico rispettare la policy dei tile server e impostare un User-Agent identificabile.


## Compilazione cloud senza PC (GitHub Actions)
È incluso `.github/workflows/build-apk.yml`. Se carichi tutti i file del progetto in un repository GitHub, la workflow può compilare `app-debug.apk` su un runner cloud:
1. Crea un repository GitHub dal browser del telefono.
2. Carica i file e le cartelle del progetto nel repository (non il solo ZIP).
3. Apri la scheda Actions e avvia `Build Android APK` (oppure il build parte al push su `main`).
4. Quando termina, apri la run e scarica l'artifact `ArezzoBusMap-debug-apk`.
5. Estrai lo ZIP dell'artifact e installa l'APK sul telefono, autorizzando l'installazione per il browser/file manager se Android lo richiede.

La compilazione cloud produce solo un APK debug; non certifica che il feed GTFS e tutti i casi d'uso siano stati validati.
